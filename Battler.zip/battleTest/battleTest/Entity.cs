﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Entity
    {
        public int maxHP;
        public int currentHP;

        public Entity(int maxHP, int currentHP)
        {
            this.maxHP = maxHP;
            this.currentHP = currentHP;
        }
    }
}
