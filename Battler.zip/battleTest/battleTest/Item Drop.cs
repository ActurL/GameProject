﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace battleTest
{
    class Item_Drop
    {
        public Item item;
        public int dropChance;
        public int maxDropCount;

        public Item_Drop(Item item, int dropChance, int maxDropCount)
        {
            this.item = item;
            this.dropChance = dropChance;
            this.maxDropCount = maxDropCount;
        }
    }
}
